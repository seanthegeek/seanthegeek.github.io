#!/bin/sh

wait=0


cd input/

echo "Sorting txt input files..."
ls *.txt | xargs -I {} sort -o {} {}

echo "Updating dotgov.csv..."

wget --quiet -O dotgov.csv https://raw.githubusercontent.com/GSA/data/master/dotgov-domains/current-federal.csv
cd ..

echo "Checking high-profile USG domains..."
checkdmarc --debug --skip-tls --wait $wait input/usg-high-profile.txt -o output/usg-high-profile.json output/usg-high-profile.csv

echo "Checking USG IC domains..."
checkdmarc --debug --skip-tls --wait $wait input/ic.txt -o output/ic.json output/ic.csv

echo "Checking USG IC supporting agency domains..."
checkdmarc --debug --skip-tls --wait $wait input/ic-supporting.txt -o output/ic-supporting.json output/ic-supporting.csv

echo "Checking USG IC contractor domains..."
checkdmarc --debug --skip-tls --wait $wait input/contractors.txt -o output/contractors.json output/contractors.csv

echo "Checking federal .gov domains..."
checkdmarc --debug --skip-tls --wait $wait input/dotgov.csv -o output/dotgov.json output/dotgov.csv

