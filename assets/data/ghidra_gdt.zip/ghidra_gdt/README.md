
# About

These files are originally from https://github.com/0x6d696368/ghidra-data/tree/master/typeinfo
